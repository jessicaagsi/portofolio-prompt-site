# Portfolio Prompt Site

A simple static website for publicly sharing a reusable Google Gemini portfolio-builder prompt.

## Edit it

The easiest files to edit are:

- `index.html` → page text, sections and structure
- `style.css` → colors, spacing, typography and layout
- `script.js` → the actual prompt shown on the page

No React or build step is required for this site.

## Publish it

You can upload these files to GitHub Pages, Netlify, or another static hosting service.

For a public QR code, point the QR code to the final published website URL.

## Privacy

Keep personal/private information out of the public prompt. Use placeholders such as:
- [Your Name]
- [Your University]
- [your@email.com]

Do not publish a real ID card or other sensitive personal documents on a public page.


## Creator attribution

Original prompt and site concept by **Jessica Agnesia Suryadi**.

The creator credit is intentionally included in:
- the website footer,
- the HTML author metadata/source comment, and
- the reusable prompt displayed on the page.

The credit can technically be removed by anyone who has access to the source code, so this is attribution protection rather than a technical anti-copy mechanism.
